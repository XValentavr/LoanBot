import enum


class InlineButtonsHelperEnum(str, enum.Enum):
    READY: str = "ready"
    CHANGE: str = "change"
    OTHER: str = "Другое"
