from bot import loan

if __name__ == '__main__':
    loan.polling(none_stop=True, interval=0, allowed_updates=None)
